## 1.0.7（2021-02-25）
- 修复 easycom 下，找不到 uni-status-bar 的bug
## 1.0.6（2021-02-05）
- 优化 组件引用关系，通过uni_modules引用组件
## 1.0.5（2021-02-05）
- 调整为uni_modules目录规范

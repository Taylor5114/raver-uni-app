## 1.0.2（2021-03-22）
- uni-tr 添加 selectable 属性，用于 type=selection 时，设置某行是否可由全选按钮控制
## 1.0.1（2021-02-05）
- 调整为uni_modules目录规范
